import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateReadingDto } from './dto/create-reading.dto';
import { UpdateReadingDto } from './dto/update-reading.dto';
import { PeriodCloseService } from 'src/period-close/period-close.service';
import { BulkCreateReadingDto } from './dto/bulk-create-reading.dto';

@Injectable()
export class ReadingsService {
  constructor(private readonly prisma: PrismaService,private periodClose: PeriodCloseService) {}

  private async ensureMeterExists(meterId: number) {
    const meter = await this.prisma.meter.findUnique({ where: { id: meterId } });
    if (!meter) throw new NotFoundException('Meter not found');
    return meter;
  }

  async create(dto: CreateReadingDto) {
    await this.ensureMeterExists(dto.meterId);
await this.periodClose.assertOpenOrThrow(dto.month, dto.year);

    if (dto.currentReading < dto.previousReading) {
      throw new BadRequestException('Current reading cannot be less than previous');
    }

    // prevent duplicates (meter + month + year)
    const exists = await this.prisma.meterReading.findUnique({
      where: {
        meterId_month_year: {
          meterId: dto.meterId,
          month: dto.month,
          year: dto.year,
        },
      },
    });
    if (exists) {
      throw new BadRequestException('Reading already exists for this meter/month');
    }

    const consumptionKwh = dto.currentReading - dto.previousReading;

    return this.prisma.meterReading.create({
      data: {
        meterId: dto.meterId,
        month: dto.month,
        year: dto.year,
        previousReading: dto.previousReading,
        currentReading: dto.currentReading,
        consumptionKwh,
      },
      include: { meter: true },
    });
  }

  async bulkCreate(dto: BulkCreateReadingDto) {
  const { month, year, rows } = dto;

  // 🔒 Period check (once)
  await this.periodClose.assertOpenOrThrow(month, year);

  if (!rows.length) {
    throw new BadRequestException('No readings provided');
  }

  return this.prisma.$transaction(async (tx) => {
    const created: any[] = [];

    for (const row of rows) {
      // 1️⃣ Ensure meter exists
      const meter = await tx.meter.findUnique({
        where: { id: row.meterId },
      });
      if (!meter) {
        throw new NotFoundException(
          `Meter ${row.meterId} not found`,
        );
      }

      // 2️⃣ Prevent duplicates
      const exists = await tx.meterReading.findUnique({
        where: {
          meterId_month_year: {
            meterId: row.meterId,
            month,
            year,
          },
        },
      });
      if (exists) {
        throw new BadRequestException(
          `Reading already exists for meter ${row.meterId}`,
        );
      }

      // 3️⃣ Get previous reading (last one)
      const last = await tx.meterReading.findFirst({
        where: { meterId: row.meterId },
        orderBy: [{ year: 'desc' }, { month: 'desc' }],
      });

      const previousReading = last?.currentReading ?? 0;

      if (row.currentReading < previousReading) {
        throw new BadRequestException(
          `Current reading cannot be less than previous for meter ${row.meterId}`,
        );
      }

      const consumptionKwh =
        row.currentReading - previousReading;

      // 4️⃣ Create reading
      const reading = await tx.meterReading.create({
        data: {
          meterId: row.meterId,
          month,
          year,
          previousReading,
          currentReading: row.currentReading,
          consumptionKwh,
        },
      });

      created.push(reading);
    }

    return created;
  });
}

  findAll() {
    return this.prisma.meterReading.findMany({
      orderBy: [{ year: 'desc' }, { month: 'desc' }],
      include: { meter: true },
    });
  }

  async findOne(id: number) {
    const reading = await this.prisma.meterReading.findUnique({
      where: { id },
      include: { meter: true, invoice: true },
    });
    if (!reading) throw new NotFoundException('Reading not found');
    return reading;
  }

  async update(id: number, dto: UpdateReadingDto) {
    const reading = await this.findOne(id);

    if (reading.invoice) {
      throw new BadRequestException('Cannot update reading with an invoice');
    }

    const prev = dto.previousReading ?? reading.previousReading;
    const curr = dto.currentReading ?? reading.currentReading;

    if (curr < prev) {
      throw new BadRequestException('Current reading cannot be less than previous');
    }

    return this.prisma.meterReading.update({
      where: { id },
      data: {
        ...dto,
        consumptionKwh: curr - prev,
      },
    });
  }

  async remove(id: number) {
    const reading = await this.findOne(id);

    if (reading.invoice) {
      throw new BadRequestException('Cannot delete reading with an invoice');
    }

    return this.prisma.meterReading.delete({ where: { id } });
  }

  // helpers
  findByMeter(meterId: number) {
    return this.prisma.meterReading.findMany({
      where: { meterId },
      orderBy: [{ year: 'desc' }, { month: 'desc' }],
    });
  }
}
