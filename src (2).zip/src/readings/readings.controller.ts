import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Post,
} from '@nestjs/common';
import { ReadingsService } from './readings.service';
import { CreateReadingDto } from './dto/create-reading.dto';
import { UpdateReadingDto } from './dto/update-reading.dto';
import { BulkCreateReadingDto } from './dto/bulk-create-reading.dto';

@Controller('readings')
export class ReadingsController {
  constructor(private readonly service: ReadingsService) {}

  @Post()
  create(@Body() dto: CreateReadingDto) {
    return this.service.create(dto);
  }

  @Post('bulk')
bulkCreate(@Body() dto: BulkCreateReadingDto) {
  return this.service.bulkCreate(dto);
}

  @Get()
  findAll() {
    return this.service.findAll();
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.service.findOne(id);
  }

  @Patch(':id')
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateReadingDto,
  ) {
    return this.service.update(id, dto);
  }

  @Delete(':id')
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.service.remove(id);
  }

  @Get('by-meter/:meterId')
  findByMeter(@Param('meterId', ParseIntPipe) meterId: number) {
    return this.service.findByMeter(meterId);
  }
}
